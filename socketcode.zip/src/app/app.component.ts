import { Component } from '@angular/core';
import { Http } from '@angular/http';
//import 'rxjs/add/operator/map';
import * as io from 'socket.io-client';

const socket =  io('http://10.0.8.36:3000');
var  dd = '';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: []
})

export class AppComponent {
  title = 'app';
  datas = '';
  counter = 0;
  constructor() { }
   ngOnInit() {
   	socket.on('broadcast message', 
   	 	function(msg){
	   	 	console.log(msg);
	   	 	/*Assign value to global variable than pass to class variable*/
	   	 	dd = msg;
 		 });
 		let that = this;
 		setInterval(function(){
 			that.counter += 1;
 			that.datas = dd;
 		},5000);
    }
}