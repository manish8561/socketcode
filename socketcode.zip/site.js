/*chat backend part*/
var app = require('express')();
var http = require('http');
var server = http.createServer(app);

var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";


var data = [];

var io = require('socket.io')(server);

io.on('connection', function(socket){
	console.log('user is connected!!!');
	socket.on('disconnect', function(){
	    console.log('user disconnected');
	});
	setInterval(function() {
		MongoClient.connect(url, { useNewUrlParser: true }, function(err, db) {		  
		  if (err) throw err;
		   var dbo = db.db('manishdb');
		   dbo.collection("users").find({}).toArray(function(err, result) {
		    if (err) throw err;
		    data = result;
		    io.emit('broadcast message', result);
		    //console.log(result);
		    //dbo.close();
		  });
		});	


		
        console.log('Interval is running');
    }, 5000);

 });


server.listen(3000);





